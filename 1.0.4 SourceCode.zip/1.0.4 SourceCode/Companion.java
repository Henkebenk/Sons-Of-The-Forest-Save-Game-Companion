import java.util.ArrayList;

public class Companion{
    //---[DECLARATIONS]---
    public ArrayList<String> coordinates = new ArrayList<String>();
    private ArrayList<String> saveData = new ArrayList<String>();
    private ArrayList<String> gameStateSaveData = new ArrayList<String>();
    public String name;
    public boolean isDead;
    public String aliveStatus = "Not yet set";
    public String health; public String anger; public String fear; public String fullness; public String hydration; public String energy; public String affection; public String typeID; public String outfit, outfitName;
    public String healthInt, angerInt, fearInt, fullnessInt, energyInt, hydrationInt, affectionInt;
    public int healthIndex, energyIndex, hydrationIndex, affectionIndex, stateIndex, playerKilledIndex;
    public boolean virginiaPistol = false, virginiaShotgun = false, virginiaTracker = false;
    public int companionIndex;


    //---[CONSTRUCTORS]---
    public Companion(String n, ArrayList<String> sD, ArrayList<String> gSSD){
        name = n;
        saveData = sD;
        gameStateSaveData = gSSD;
        if (n.equals("Kelvin")){
            typeID = "9";
        }
        else{
            typeID = "10";
        }
        updateCoordinates();
    }

    //---[METHODS]---
    public ArrayList<String> updateCoordinates(){
        for (int i = 0; i < saveData.size(); i++){
            String current = saveData.get(i);
            if (current.contains("TypeId") && current.contains(":" + typeID) && saveData.get(i+2).contains("Position") ) {
                companionIndex = i;

                String[] xPart = saveData.get(i+2).split(":");
                String[] yPart = saveData.get(i+3).split(":");
                String[] zPart = saveData.get(i+4).split(":");
                zPart[1] = zPart[1].replace("}","");

                for (int j = i+5; !(saveData.get(j).contains("TypeId")); j++){
                    if(saveData.get(j).contains("Health")){
                        String[] healthPart = saveData.get(j).split(":"); health = healthPart[2];healthInt = String.format("%d",(int) Double.parseDouble(health));
                        healthIndex = j;
                    }
                    else if(saveData.get(j).contains("Anger")){
                        String[] angerPart = saveData.get(j).split(":"); anger = angerPart[1];angerInt = String.format("%d",(int) Double.parseDouble(anger));
                    }
                    else if(saveData.get(j).contains("Fear")){
                        String[] fearPart = saveData.get(j).split(":"); fear = fearPart[1];fearInt = String.format("%d",(int) Double.parseDouble(fear));
                    }
                    else if(saveData.get(j).contains("Fullness")){
                        String[] fullnessPart = saveData.get(j).split(":"); fullness = fullnessPart[1]; fullnessInt = String.format("%d",(int) Double.parseDouble(fullness));
                    }
                    else if(saveData.get(j).contains("Hydration")){
                        String[] hydrationPart = saveData.get(j).split(":"); hydration = hydrationPart[1]; hydrationInt = String.format("%d",(int) Double.parseDouble(hydration));
                        hydrationIndex = j;
                    }
                    else if(saveData.get(j).contains("Energy")){
                        String[] energyPart = saveData.get(j).split(":"); energy = energyPart[1]; energyInt = String.format("%d",(int) Double.parseDouble(energy));
                        energyIndex = j;
                    }
                    else if(saveData.get(j).contains("Affection")){
                        String[] affectionPart = saveData.get(j).split(":"); affectionPart[1] = affectionPart[1].replace("}","");affection = affectionPart[1]; affectionInt = String.format("%d",(int) Double.parseDouble(affection));
                        affectionIndex = j;
                    }
                    else if(saveData.get(j).contains("EquippedItems")){
                        for (int k = j; (!(saveData.get(k).contains("OutfitId"))); k++) {
                            if (saveData.get(k).contains("529")) {
                                virginiaTracker = true;
                            } else if (saveData.get(k).contains("355")) {
                                virginiaPistol = true;
                            } else if (saveData.get(k).contains("358")) {
                                virginiaShotgun = true;
                            }
                        }
                    }
                    else if(saveData.get(j).contains("OutfitId")){
                        String[] outfitPart = saveData.get(j).split(":"); outfit = outfitPart[1];
                        if(name.equals("Kelvin")){
                            switch (outfit){
                                case "0", "-1":
                                    outfitName = "Tactical Jacket";
                                    break;
                                case "1":
                                    outfitName = "Tuxedo";
                                    break;
                                case "2":
                                    outfitName = "Pajamas";
                                    break;
                                case "3":
                                    outfitName = "Leather Jacket";
                                    break;
                                case "4":
                                    outfitName = "Hoodie";
                                    break;
                                case "6":
                                    outfitName = "Blazer";
                                    break;
                            }
                        }
                        else{
                            switch (outfit){
                                case "0", "-1":
                                    outfitName = "Swimsuit";
                                    break;
                                case "1":
                                    outfitName = "Track Suit";
                                    break;
                                case "2":
                                    outfitName = "Leather Suit";
                                    break;
                                case "3":
                                    outfitName = "Camouflage Suit";
                                    break;
                                case "4":
                                    outfitName = "Dress";
                                    break;
                            }
                        }
                    }

                    else if(saveData.get(j).contains("\"State\\\":")){
                        stateIndex = j;
                    }
                }
                coordinates.clear();
                coordinates.add(xPart[2]);
                coordinates.add(yPart[1]);
                coordinates.add(zPart[1]);
            }
            else if(current.contains("{\\\"TypeId\\\":" + typeID) && saveData.get(i+1).contains("PlayerKilled")){
                playerKilledIndex = i+1;
            }
        }
        String actor;
        if(name.equals("Kelvin")){
            actor = "IsRobbyDead";
        }
        else{
            actor = "IsVirginiaDead";
        }
        for(int i = 0; i < gameStateSaveData.size(); i++){
            if(gameStateSaveData.get(i).contains(actor)){
                String[] isDeadPart = gameStateSaveData.get(i).split(":");
                if (isDeadPart[1].equals("true")){
                    isDead = true;
                    aliveStatus = "Dead";
                }
                else{
                    isDead = false;
                    aliveStatus = "Alive";
                }
            }
        }
        return coordinates;
    }
    public String setCoordinates(ArrayList<String> c){
        coordinates = c;
        return "Coordinates updated for: " + name;
    }

    public String writeCoordinates(){
        String[] x = coordinates.get(0).split("\\.");String[] y = coordinates.get(1).split("\\.");String[] z = coordinates.get(2).split("\\.");
        String s = "X:" + x[0] + " Y:" + y[0] + " Z:" + z[0];
        return s;
    }

    public String getName(){
        return name;
    }

    public boolean getIsDead(ArrayList<String> gameStateSaveData){
        String actor;
        if (name.equals("Kelvin")){
            actor = "IsRobbyDead";
        }
        else{
            actor= "IsVirginiaDead";
        }

        for (int i = 0; i < gameStateSaveData.size(); i++){
            String current = gameStateSaveData.get(i);
            if (current.contains(actor)) {
                String[] status = gameStateSaveData.get(i).split(":");
                if(status[1].equals("1")){
                    isDead = true;
                }
                else{
                    isDead = false;
                }
            }
        }

        return isDead;
    }
}
