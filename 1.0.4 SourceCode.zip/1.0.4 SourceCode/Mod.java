import java.io.*;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Mod {
    //---[DECLARATIONS]---
    protected ArrayList<String> saveData = new ArrayList<>();
    protected ArrayList<String> gameStateSaveData = new ArrayList<>();
    protected ArrayList<String> playerStateSaveData = new ArrayList<>();
    protected ArrayList<String> playerInventorySaveData = new ArrayList<>();
    protected ArrayList<String> worldObjectLocatorManagerSaveData = new ArrayList<>();
    public int numberOfTrees;
    public Companion kelvin;
    public Companion virginia;
    public Player player;
    public String saveTimeString;
    public String saveDays;
    public String saveDifficulty;
    public String saveDaysDifficulty;
    public String saveSpawn;
    public String storyComplete;
    private String saveFilePath;
    public boolean kelvinDead, virginiaDead;
    public int kelvinDeadIndex, virginiaDeadIndex;

    //---[CONSTRUCTORS]---

    //---[METHODS]---
    public String load(String filePath){
        saveFilePath = filePath;
        try { //--SaveData
            File f = new File(filePath + "SaveData.json");
            BufferedReader br = new BufferedReader(new FileReader(f));

            String line = br.readLine();
            String[] tempDetails = line.split(",");
            saveData.addAll(Arrays.asList(tempDetails)); //Replaces for-loop
            br.close();
        }
        catch (FileNotFoundException e) { // If file was not found
            System.out.println("[Error]: File not found!");
            //throw new RuntimeException(e);
            return "Try again";
        }
        catch (IOException e) { // If Line could not be read
            System.out.println("[Error]: Could not read line!");
            return "Try again";
        }

        try { //--GameStateSaveData
            File f = new File(filePath + "GameStateSaveData.json");
            BufferedReader br = new BufferedReader(new FileReader(f));

            String line = br.readLine();
            String[] tempDetails = line.split(",");
            gameStateSaveData.addAll(Arrays.asList(tempDetails)); //Replaces for-loop
            br.close();
            setSaveDataInfo();
        }
        catch (FileNotFoundException e) { // If file was not found
            System.out.println("[Error]: File not found!");
            //throw new RuntimeException(e);
            return "Try again";
        }
        catch (IOException e) { // If Line could not be read
            System.out.println("[Error]: Could not read line!");
            return "Try again";
        }

        try { //--PlayerStateData
            File f = new File(filePath + "PlayerStateSaveData.json");
            BufferedReader br = new BufferedReader(new FileReader(f));

            String line = br.readLine();
            String[] tempDetails = line.split(",");
            playerStateSaveData.addAll(Arrays.asList(tempDetails)); //Replaces for-loop
            br.close();
        }
        catch (FileNotFoundException e) { // If file was not found
            System.out.println("[Error]: File not found!");
            //throw new RuntimeException(e);
            return "Try again";
        }
        catch (IOException e) { // If Line could not be read
            System.out.println("[Error]: Could not read line!");
            return "Try again";
        }

        try { //--PlayerInventorySaveData
            File f = new File(filePath + "PlayerInventorySaveData.json");
            BufferedReader br = new BufferedReader(new FileReader(f));

            String line = br.readLine();
            String[] tempDetails = line.split(",");
            playerInventorySaveData.addAll(Arrays.asList(tempDetails)); //Replaces for-loop
            br.close();
        }
        catch (FileNotFoundException e) { // If file was not found
            System.out.println("[Error]: File not found!");
            return "Try again";
        }
        catch (IOException e) { // If Line could not be read
            System.out.println("[Error]: Could not read line!");
            return "Try again";
        }

        try { //--WorldObjectLocatorManager
            File f = new File(filePath + "WorldObjectLocatorManagerSaveData.json");
            BufferedReader br = new BufferedReader(new FileReader(f));

            String line = br.readLine();
            String[] tempDetails = line.split(",");
            worldObjectLocatorManagerSaveData.addAll(Arrays.asList(tempDetails)); //Replaces for-loop
            br.close();
        }
        catch (FileNotFoundException e) { // If file was not found
            System.out.println("[Error]: File not found!");
            return "Try again";
        }
        catch (IOException e) { // If Line could not be read
            System.out.println("[Error]: Could not read line!");
            return "Try again";
        }

        return "[SONS OF THE FOREST | SAVE COMPANION]\n   •SaveData file loaded with " + saveData.size() + " lines of code\n" + "   •GameStateSaveData file loaded with " + gameStateSaveData.size() + " lines of code\n" + loadCompanions() + "\n" + loadPlayer() + "\n" + loadEnvironment();
    }

    public String getFilePath(){
        return saveFilePath;
    }

    private String loadPlayer(){
        player = new Player(playerStateSaveData, playerInventorySaveData);
        return "   •Player loaded";
    }

    private String loadCompanions(){
        kelvin = new Companion("Kelvin", saveData, gameStateSaveData);
        virginia = new Companion("Virginia", saveData, gameStateSaveData);
        return "   •Companions loaded";
    }

    private String loadEnvironment(){
        numberOfTrees=0;
        for (String current : worldObjectLocatorManagerSaveData) {
            if (current.contains("Value")) {
                numberOfTrees++;
            }
        }
        return "   •Environment loaded";
    }

    public void regrowAllTrees(){
        for (int i = 0; i < worldObjectLocatorManagerSaveData.size(); i++) {
            String current = worldObjectLocatorManagerSaveData.get(i);
            if (current.contains("Value")) {
                if(worldObjectLocatorManagerSaveData.get(i-1).contains("\\\"SerializedStates\\\":")){
                    worldObjectLocatorManagerSaveData.set(i-1,"\\\"SerializedStates\\\":[]");
                    worldObjectLocatorManagerSaveData.remove(i);
                    i -= 1;
                }
                else{
                    worldObjectLocatorManagerSaveData.remove(i);
                    worldObjectLocatorManagerSaveData.remove(i-1);
                    i -= 2;
                }
            }
        }
        numberOfTrees=0;
        saveWorldObjectLocatorManagerSaveData();
    }

    public void regrowStumps(){
        for (int i = 0; i < worldObjectLocatorManagerSaveData.size(); i++) {
            String current = worldObjectLocatorManagerSaveData.get(i);
            if (current.contains("\\\"Value\\\":3}")) {
                if(worldObjectLocatorManagerSaveData.get(i-1).contains("\\\"SerializedStates\\\":")){
                    worldObjectLocatorManagerSaveData.set(i+1, "\\\"SerializedStates\\\":[" + worldObjectLocatorManagerSaveData.get(i+1));
                    worldObjectLocatorManagerSaveData.remove(i);
                    worldObjectLocatorManagerSaveData.remove(i-1);
                    i -= 2;
                }
                else{
                    if(current.contains("]")){
                        worldObjectLocatorManagerSaveData.set(i-2, worldObjectLocatorManagerSaveData.get(i-2) + "]");
                    }
                    worldObjectLocatorManagerSaveData.remove(i);
                    worldObjectLocatorManagerSaveData.remove(i-1);
                    i -= 2;
                }
            }
        }
        loadEnvironment();
        saveWorldObjectLocatorManagerSaveData();
    }

    public void setPlayerStats(){
        playerStateSaveData.set(player.healthIndex, "\\\"FloatValue\\\":" + player.health);
        playerStateSaveData.set(player.targetHealthIndex, "\\\"FloatValue\\\":" + player.health);
        playerStateSaveData.set(player.energyIndex, "\\\"FloatValue\\\":" + player.energy);
        playerStateSaveData.set(player.restIndex, "\\\"FloatValue\\\":" + player.rest);
        playerStateSaveData.set(player.fullnessIndex, "\\\"FloatValue\\\":" + player.fullness);
        playerStateSaveData.set(player.hydrationIndex, "\\\"FloatValue\\\":" + player.hydration);
    }

    public void setPlayerAmmo(){
        playerInventorySaveData.set(player.ammoBuckIndex, "\\\"TotalCount\\\":" + player.ammoBuck);
        playerInventorySaveData.set(player.ammoSlugIndex, "\\\"TotalCount\\\":" + player.ammoSlug);
        playerInventorySaveData.set(player.ammoPistolIndex, "\\\"TotalCount\\\":" + player.ammoPistol);
        playerInventorySaveData.set(player.ammoArrowCarbonIndex, "\\\"TotalCount\\\":" + player.ammoArrowCarbon);
        playerInventorySaveData.set(player.ammoArrowPrintedIndex, "\\\"TotalCount\\\":" + player.ammoArrowPrinted);
        playerInventorySaveData.set(player.ammoArrowStoneIndex, "\\\"TotalCount\\\":" + player.ammoArrowStone);
    }

    public void setPlayerThrowables(){
        playerInventorySaveData.set(player.throwablesFragIndex, "\\\"TotalCount\\\":" + player.throwablesFrag);
        playerInventorySaveData.set(player.throwablesFlareIndex, "\\\"TotalCount\\\":" + player.throwablesFlare);
        playerInventorySaveData.set(player.throwablesTimeBombIndex, "\\\"TotalCount\\\":" + player.throwablesTimeBomb);
        playerInventorySaveData.set(player.throwablesMolotovIndex, "\\\"TotalCount\\\":" + player.throwablesMolotov);
    }

    public void setKelvinStats(){
        saveData.set(kelvin.healthIndex, "\\\"Stats\\\":{\\\"Health\\\":" + kelvin.health);
        saveData.set(kelvin.energyIndex, "\\\"Energy\\\":" + kelvin.energy);
        saveData.set(kelvin.hydrationIndex, "\\\"Hydration\\\":" + kelvin.hydration);
        saveData.set(kelvin.affectionIndex, "\\\"Affection\\\":" + kelvin.affection + "}");

    }

    public void setVirginiaStats(){
        saveData.set(virginia.healthIndex, "\\\"Stats\\\":{\\\"Health\\\":" + virginia.health);
        saveData.set(virginia.energyIndex, "\\\"Energy\\\":" + virginia.energy);
        saveData.set(virginia.hydrationIndex, "\\\"Hydration\\\":" + virginia.hydration);
        saveData.set(virginia.affectionIndex, "\\\"Affection\\\":" + virginia.affection + "}");
    }

    public void setCompanionCoordinates(){
        saveData.set(kelvin.companionIndex+2,"\\\"Position\\\":{\\\"x\\\":" + kelvin.coordinates.get(0));
        saveData.set(kelvin.companionIndex+3,"\\\"y\\\":" + kelvin.coordinates.get(1));
        saveData.set(kelvin.companionIndex+4,"\\\"z\\\":" + kelvin.coordinates.get(2) + "}");

        saveData.set(virginia.companionIndex+2,"\\\"Position\\\":{\\\"x\\\":" + virginia.coordinates.get(0));
        saveData.set(virginia.companionIndex+3,"\\\"y\\\":" + virginia.coordinates.get(1));
        saveData.set(virginia.companionIndex+4,"\\\"z\\\":" + virginia.coordinates.get(2) + "}");
    }

    public void setSaveDataInfo(){
        for (int i = 0; i < gameStateSaveData.size(); i++) {
            if(gameStateSaveData.get(i).contains("SaveTime")){
                saveTimeString = gameStateSaveData.get(i); saveTimeString = saveTimeString.replace("\\\"SaveTime\\\":\\\"",""); saveTimeString = saveTimeString.replace("\\\"", "");
            }
            if(gameStateSaveData.get(i).contains("GameDays")){
                saveDays = gameStateSaveData.get(i).replace("\\\"GameDays\\\":","");
            }
            if(gameStateSaveData.get(i).contains("GameType")){
                saveDifficulty = gameStateSaveData.get(i).replace("\\\"GameType\\\":\\\"",""); saveDifficulty = saveDifficulty.replace("\\\"","");
            }
            if(gameStateSaveData.get(i).contains("CrashSite")){
                saveSpawn = gameStateSaveData.get(i).replace("\\\"CrashSite\\\":\\\"",""); saveSpawn = saveSpawn.replace("\\\"","");
                saveSpawn = saveSpawn.substring(0,1).toUpperCase() + saveSpawn.substring(1) + " crash-site";
            }
            if(gameStateSaveData.get(i).contains("CoreGameCompleted")){
                String[] storyCompletedPart = gameStateSaveData.get(i).split(":");
                if(storyCompletedPart[1].equals("false")){
                    storyComplete = "Story not completed";
                }
                else{
                    storyComplete = "Story completed";
                }
            }
            if(gameStateSaveData.get(i).contains("IsRobbyDead")){
                kelvinDeadIndex = i;
                if(gameStateSaveData.get(i).contains("true")){
                    kelvinDead = true;
                }
                else{
                    kelvinDead = false;
                }
            }
            if(gameStateSaveData.get(i).contains("IsVirginiaDead")){
                virginiaDeadIndex = i;
                if(gameStateSaveData.get(i).contains("true")){
                    virginiaDead = true;
                }
                else{
                    virginiaDead = false;
                }
            }
        }
        LocalDateTime saveTime = LocalDateTime.parse(saveTimeString, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
        ZonedDateTime zonedSaveTime = saveTime.atZone(ZoneId.systemDefault());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMMM yyyy - hh:mm:ssa");
        saveTimeString = zonedSaveTime.format(formatter);
        System.out.println(saveTimeString);
        saveDaysDifficulty = "Day:" + saveDays + " - " + saveDifficulty;
    }

    public void setSaveDifficulty(){
        for (int i = 0; i < gameStateSaveData.size(); i++) {
            if(gameStateSaveData.get(i).contains("GameType")){
                gameStateSaveData.set(i, "\\\"GameType\\\":\\\"" + saveDifficulty + "\\\"");
            }
        }
        saveDaysDifficulty = "Day:" + saveDays + " - " + saveDifficulty;
    }

    public void reviveCompanion(Companion c){
        if (c == kelvin){
            gameStateSaveData.set(kelvinDeadIndex, "\\\"IsRobbyDead\\\":false");
            saveData.set(kelvin.healthIndex, "\\\"Stats\\\":{\\\"Health\\\":100.0");
            saveData.set(kelvin.stateIndex, "\\\"State\\\":2");
            saveData.set(kelvin.playerKilledIndex,"\\\"PlayerKilled\\\":0}");
        }
        else{
            gameStateSaveData.set(virginiaDeadIndex, "\\\"IsVirginiaDead\\\":false");
            saveData.set(virginia.healthIndex, "\\\"Stats\\\":{\\\"Health\\\":100.0");
            saveData.set(virginia.stateIndex, "\\\"State\\\":2");
            saveData.set(virginia.playerKilledIndex,"\\\"PlayerKilled\\\":0}");
        }

    }

    public String saveSaveData(){
        try {
            File f = new File(saveFilePath + "SaveData.json");
            f.createNewFile();
            BufferedWriter w = new BufferedWriter(new FileWriter(f, false));

            String s ="";
            for(int i = 0; i < saveData.size()-1; i++){
                s+= saveData.get(i)+",";
            }
            s+= saveData.get(saveData.size()-1);
            w.write(s);
            w.flush();
            w.close();
            return "saved SaveData";
        } catch (IOException e) {
            return "Could not save to the file";
        }

    }
    public String saveGameStateSaveData(){
        try {
            File f = new File(saveFilePath + "GameStateSaveData.json");
            f.createNewFile();
            BufferedWriter w = new BufferedWriter(new FileWriter(f, false));

            String s ="";
            for(int i = 0; i < gameStateSaveData.size()-1; i++){
                s+= gameStateSaveData.get(i)+",";
            }
            s+= gameStateSaveData.get(gameStateSaveData.size()-1);
            w.write(s);
            w.flush();
            w.close();
            return "saved SaveData";
        } catch (IOException e) {
            return "Could not save to the file";
        }

    }
    public String saveWorldObjectLocatorManagerSaveData(){
        try {
            File f = new File(saveFilePath + "WorldObjectLocatorManagerSaveData.json");
            f.createNewFile();
            BufferedWriter w = new BufferedWriter(new FileWriter(f, false));

            String s ="";
            for(int i = 0; i < worldObjectLocatorManagerSaveData.size()-1; i++){
                s+= worldObjectLocatorManagerSaveData.get(i)+",";
            }
            s+= worldObjectLocatorManagerSaveData.get(worldObjectLocatorManagerSaveData.size()-1);
            w.write(s);
            w.flush();
            w.close();
            return "saved WorldObjectLocatorManagerSaveData";
        } catch (IOException e) {
            return "Could not save to the file";
        }
    }
    public String savePlayerStateSaveData(){
        try {
            File f = new File(saveFilePath + "PlayerStateSaveData.json");
            f.createNewFile();
            BufferedWriter w = new BufferedWriter(new FileWriter(f, false));

            String s ="";
            for(int i = 0; i < playerStateSaveData.size()-1; i++){
                s+= playerStateSaveData.get(i)+",";
            }
            s+= playerStateSaveData.get(playerStateSaveData.size()-1);
            w.write(s);
            w.flush();
            w.close();
            return "saved WorldObjectLocatorManagerSaveData";
        } catch (IOException e) {
            return "Could not save to the file";
        }
    }
    public String savePlayerInventorySaveData(){
        try {
            File f = new File(saveFilePath + "PlayerInventorySaveData.json");
            f.createNewFile();
            BufferedWriter w = new BufferedWriter(new FileWriter(f, false));

            String s ="";
            for(int i = 0; i < playerInventorySaveData.size()-1; i++){
                s+= playerInventorySaveData.get(i)+",";
            }
            s+= playerInventorySaveData.get(playerInventorySaveData.size()-1);
            w.write(s);
            w.flush();
            w.close();
            System.out.println("saved PlayerInventorySaveData");
            return "saved PlayerInventorySaveData";
        } catch (IOException e) {
            return "Could not save to the file";
        }
    }
}