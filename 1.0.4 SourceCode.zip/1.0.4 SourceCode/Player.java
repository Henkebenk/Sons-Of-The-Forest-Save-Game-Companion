import java.util.ArrayList;

public class Player {
    //---[DECLARATIONS]---
    public ArrayList<String> coordinates = new ArrayList<String>();
    private ArrayList<String> playerStateSaveData = new ArrayList<String>();
    private ArrayList<String> playerInventorySaveData = new ArrayList<String>();
    public String health, fullness, hydration, energy, rest, maxHealth;
    public String healthInt, fullnessInt, hydrationInt, energyInt, restInt, maxHealthInt;
    public int healthIndex, fullnessIndex, hydrationIndex, energyIndex, restIndex, targetHealthIndex, maxHealthIndex;
    public String ammoBuck = "0", ammoSlug = "0", ammoPistol = "0", ammoArrowCarbon = "0", ammoArrowPrinted = "0", ammoArrowStone = "0", throwablesFrag = "0", throwablesFlare = "0", throwablesTimeBomb = "0", throwablesMolotov = "0";
    public int ammoBuckIndex, ammoSlugIndex, ammoPistolIndex, ammoArrowCarbonIndex, ammoArrowPrintedIndex, ammoArrowStoneIndex, throwablesFragIndex, throwablesFlareIndex, throwablesTimeBombIndex, throwablesMolotovIndex;
    public boolean ammoBuckFound = false, ammoSlugFound = false, ammoPistolFound = false, ammoArrowCarbonFound = false, ammoArrowPrintedFound = false, ammoArrowStoneFound = false, throwablesFragFound = false, throwablesFlareFound = false, throwablesTimeBombFound = false, throwablesMolotovFound = false;
    private int playerIndex;

    //---[CONSTRUCTORS]---
    public Player(ArrayList<String> pSSD, ArrayList<String> pISD){
        playerStateSaveData = pSSD;
        playerInventorySaveData = pISD;
        getValues();
    }

    //---[METHODS]---
    public void getValues(){
        for (int i = 0; i < playerStateSaveData.size(); i++){
            String current = playerStateSaveData.get(i);
            if (current.contains("position")) {
                for (int j = i; !(playerStateSaveData.get(j).contains("IsSet")); j++) {
                    if (playerStateSaveData.get(j).contains("[")){
                        String[] xPart = playerStateSaveData.get(j).split("\\[");
                        String yPart = playerStateSaveData.get(j+1);
                        String[] zPart = playerStateSaveData.get(j+2).split("\\]");;
                        coordinates.clear();
                        coordinates.add(xPart[1]);coordinates.add(yPart); coordinates.add(zPart[0]);
                    }
                }
            }
            if(current.contains("CurrentHealth\\")){
                int j;
                for(j = i; !(playerStateSaveData.get(j).contains("FloatValue")); j++){}
                String[] healthPart = playerStateSaveData.get(j).split(":"); health = healthPart[1];healthInt = String.format("%d",(int) Double.parseDouble(health));
                healthIndex = j;
            }
            else if(current.contains("TargetHealth\\")){
                int j;
                for(j = i; !(playerStateSaveData.get(j).contains("FloatValue")); j++){}
                targetHealthIndex = j;
            }
            else if(current.contains("MaxHealth\\")){
                int j;
                for(j = i; !(playerStateSaveData.get(j).contains("FloatValue")); j++){}
                String[] maxHealthPart = playerStateSaveData.get(j).split(":"); maxHealth = maxHealthPart[1]; maxHealthInt = String.format("%d",(int) Double.parseDouble(maxHealth));
                maxHealthIndex = j;
            }
            else if(current.contains("Stamina\\")){
                int j;
                for(j = i; !(playerStateSaveData.get(j).contains("FloatValue")); j++){}
                String[] energyPart = playerStateSaveData.get(j).split(":"); energy = energyPart[1];energyInt = String.format("%d",(int) Double.parseDouble(energy));
                energyIndex = j;
            }
            else if(current.contains("Fullness\\")){
                int j;
                for(j = i; !(playerStateSaveData.get(j).contains("FloatValue")); j++){}
                String[] fullnessPart = playerStateSaveData.get(j).split(":"); fullness = fullnessPart[1];fullnessInt = String.format("%d",(int) Double.parseDouble(fullness));
                fullnessIndex = j;
            }
            else if(current.contains("Hydration\\")){
                int j;
                for(j = i; !(playerStateSaveData.get(j).contains("FloatValue")); j++){}
                String[] hydrationPart = playerStateSaveData.get(j).split(":"); hydration = hydrationPart[1];hydrationInt = String.format("%d",(int) Double.parseDouble(hydration));
                hydrationIndex = j;
            }
            else if(current.contains("Rest\\")){
                int j;
                for(j = i; !(playerStateSaveData.get(j).contains("FloatValue")); j++){}
                String[] restPart = playerStateSaveData.get(j).split(":"); rest = restPart[1];restInt = String.format("%d",(int) Double.parseDouble(rest));
                restIndex = j;
            }
        }

        //Buckshot 364, Slug 363, Pistol ammo 362, Carbon fibre arrow 373, Printed arrow 618, Stone arrow 507, Frag grenade 381, Flare 440, Time bomb 417, Molotov 388
        for (int i = 0; i < playerInventorySaveData.size(); i++){
            String current = playerInventorySaveData.get(i);
            if (current.contains("ItemId\\\":364")) {
                String[] buckPart = playerInventorySaveData.get(i+1).split(":");
                ammoBuck = buckPart[1];
                ammoBuckIndex = i+1;
                ammoBuckFound = true;
            }
            else if (current.contains("ItemId\\\":363")) {
                String[] slugPart = playerInventorySaveData.get(i+1).split(":");
                ammoSlug = slugPart[1];
                ammoSlugIndex = i+1;
                ammoSlugFound = true;
            }
            else if (current.contains("ItemId\\\":362")) {
                String[] pistolPart = playerInventorySaveData.get(i+1).split(":");
                ammoPistol = pistolPart[1];
                ammoPistolIndex = i+1;
                ammoPistolFound = true;
            }
            else if (current.contains("ItemId\\\":373")) {
                String[] carbonPart = playerInventorySaveData.get(i+1).split(":");
                ammoArrowCarbon = carbonPart[1];
                ammoArrowCarbonIndex = i+1;
                ammoArrowCarbonFound = true;
            }
            else if (current.contains("ItemId\\\":618")) {
                String[] printedPart = playerInventorySaveData.get(i+1).split(":");
                ammoArrowPrinted = printedPart[1];
                ammoArrowPrintedIndex = i+1;
                ammoArrowPrintedFound = true;
            }
            else if (current.contains("ItemId\\\":507")) {
                String[] stonePart = playerInventorySaveData.get(i+1).split(":");
                ammoArrowStone = stonePart[1];
                ammoArrowStoneIndex = i+1;
                ammoArrowStoneFound = true;
            }
            else if (current.contains("ItemId\\\":381")) {
                String[] fragPart = playerInventorySaveData.get(i+1).split(":");
                throwablesFrag = fragPart[1];
                throwablesFragIndex = i+1;
                throwablesFragFound = true;
            }
            else if (current.contains("ItemId\\\":440")) {
                String[] flarePart = playerInventorySaveData.get(i+1).split(":");
                throwablesFlare = flarePart[1];
                throwablesFlareIndex = i+1;
                throwablesFlareFound = true;
            }
            else if (current.contains("ItemId\\\":417")) {
                String[] timeBombPart = playerInventorySaveData.get(i+1).split(":");
                throwablesTimeBomb = timeBombPart[1];
                throwablesTimeBombIndex = i+1;
                throwablesTimeBombFound = true;
            }
            else if (current.contains("ItemId\\\":388")) {
                String[] molotovPart = playerInventorySaveData.get(i+1).split(":");
                throwablesMolotov = molotovPart[1];
                throwablesMolotovIndex = i+1;
                throwablesMolotovFound = true;
            }
        }

        //Buckshot 364, Slug 363, Pistol ammo 362, Carbon fibre arrow 373, Printed arrow 618, Stone arrow 507, Frag grenade 381, Flare 440, Time bomb 417, Molotov 388
        if(!ammoBuckFound){
            playerInventorySaveData.set(playerInventorySaveData.size()-1, playerInventorySaveData.get(playerInventorySaveData.size()-1).replace("]}}\"}}",""));
            playerInventorySaveData.add("{\\\"ItemId\\\":364"); playerInventorySaveData.add("\\\"TotalCount\\\":0"); playerInventorySaveData.add("\\\"UniqueItems\\\":[]}]}}\"}}");
            ammoBuckIndex = playerInventorySaveData.size()-2;
        }
        if(!ammoSlugFound){
            playerInventorySaveData.set(playerInventorySaveData.size()-1, playerInventorySaveData.get(playerInventorySaveData.size()-1).replace("]}}\"}}",""));
            playerInventorySaveData.add("{\\\"ItemId\\\":363"); playerInventorySaveData.add("\\\"TotalCount\\\":0"); playerInventorySaveData.add("\\\"UniqueItems\\\":[]}]}}\"}}");
            ammoSlugIndex = playerInventorySaveData.size()-2;
        }
        if(!ammoPistolFound){
            playerInventorySaveData.set(playerInventorySaveData.size()-1, playerInventorySaveData.get(playerInventorySaveData.size()-1).replace("]}}\"}}",""));
            playerInventorySaveData.add("{\\\"ItemId\\\":362"); playerInventorySaveData.add("\\\"TotalCount\\\":0"); playerInventorySaveData.add("\\\"UniqueItems\\\":[]}]}}\"}}");
            ammoPistolIndex = playerInventorySaveData.size()-2;
        }
        if(!ammoArrowCarbonFound){
            playerInventorySaveData.set(playerInventorySaveData.size()-1, playerInventorySaveData.get(playerInventorySaveData.size()-1).replace("]}}\"}}",""));
            playerInventorySaveData.add("{\\\"ItemId\\\":373"); playerInventorySaveData.add("\\\"TotalCount\\\":0"); playerInventorySaveData.add("\\\"UniqueItems\\\":[]}]}}\"}}");
            ammoArrowCarbonIndex = playerInventorySaveData.size()-2;
        }
        if(!ammoArrowPrintedFound){
            playerInventorySaveData.set(playerInventorySaveData.size()-1, playerInventorySaveData.get(playerInventorySaveData.size()-1).replace("]}}\"}}",""));
            playerInventorySaveData.add("{\\\"ItemId\\\":618"); playerInventorySaveData.add("\\\"TotalCount\\\":0"); playerInventorySaveData.add("\\\"UniqueItems\\\":[]}]}}\"}}");
            ammoArrowPrintedIndex = playerInventorySaveData.size()-2;
        }
        if(!ammoArrowStoneFound){
            playerInventorySaveData.set(playerInventorySaveData.size()-1, playerInventorySaveData.get(playerInventorySaveData.size()-1).replace("]}}\"}}",""));
            playerInventorySaveData.add("{\\\"ItemId\\\":507"); playerInventorySaveData.add("\\\"TotalCount\\\":0"); playerInventorySaveData.add("\\\"UniqueItems\\\":[]}]}}\"}}");
            ammoArrowStoneIndex = playerInventorySaveData.size()-2;
        }
        if(!throwablesFragFound){
            playerInventorySaveData.set(playerInventorySaveData.size()-1, playerInventorySaveData.get(playerInventorySaveData.size()-1).replace("]}}\"}}",""));
            playerInventorySaveData.add("{\\\"ItemId\\\":381"); playerInventorySaveData.add("\\\"TotalCount\\\":0"); playerInventorySaveData.add("\\\"UniqueItems\\\":[]}]}}\"}}");
            throwablesFragIndex = playerInventorySaveData.size()-2;
        }
        if(!throwablesFlareFound){
            playerInventorySaveData.set(playerInventorySaveData.size()-1, playerInventorySaveData.get(playerInventorySaveData.size()-1).replace("]}}\"}}",""));
            playerInventorySaveData.add("{\\\"ItemId\\\":440"); playerInventorySaveData.add("\\\"TotalCount\\\":0"); playerInventorySaveData.add("\\\"UniqueItems\\\":[]}]}}\"}}");
            throwablesFlareIndex = playerInventorySaveData.size()-2;
        }
        if(!throwablesTimeBombFound){
            playerInventorySaveData.set(playerInventorySaveData.size()-1, playerInventorySaveData.get(playerInventorySaveData.size()-1).replace("]}}\"}}",""));
            playerInventorySaveData.add("{\\\"ItemId\\\":417"); playerInventorySaveData.add("\\\"TotalCount\\\":0"); playerInventorySaveData.add("\\\"UniqueItems\\\":[]}]}}\"}}");
            throwablesTimeBombIndex = playerInventorySaveData.size()-2;
        }
        if(!throwablesMolotovFound){
            playerInventorySaveData.set(playerInventorySaveData.size()-1, playerInventorySaveData.get(playerInventorySaveData.size()-1).replace("]}}\"}}",""));
            playerInventorySaveData.add("{\\\"ItemId\\\":388"); playerInventorySaveData.add("\\\"TotalCount\\\":0"); playerInventorySaveData.add("\\\"UniqueItems\\\":[]}]}}\"}}");
            throwablesMolotovIndex = playerInventorySaveData.size()-2;
        }
    }

    public String writeCoordinates(){
        String[] x = coordinates.get(0).split("\\.");String[] y = coordinates.get(1).split("\\.");String[] z = coordinates.get(2).split("\\.");
        String s = "X:" + x[0] + " Y:" + y[0] + " Z:" + z[0];
        return s;
    }
}
