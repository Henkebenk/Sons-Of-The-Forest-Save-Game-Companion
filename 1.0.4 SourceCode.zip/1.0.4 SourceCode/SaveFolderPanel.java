import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;


public class SaveFolderPanel extends JPanel {
    //---[DECLARATIONS]---
    public List<File> singlePlayerFolders;
    public List<File> multiPlayerFolders;
    // TODO check if necessary private final Menu men;

    //---[CONSTRUCTORS]---
    public SaveFolderPanel(Menu menu) {
        // TODO Check if necessary this.men = menu;
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        singlePlayerFolders = getSinglePlayerFolders();
        multiPlayerFolders = getMultiPlayerFolders();

        JLabel singlePlayerSpacer = new JLabel("SinglePlayer");
        singlePlayerSpacer.setFont(new Font("Arial", Font.BOLD, 14));
        singlePlayerSpacer.setForeground(new Color(0xBBBBBB));
        singlePlayerSpacer.setIcon(new ImageIcon("src\\images\\player.png"));
        singlePlayerSpacer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(3, 280, 0, 3, new Color(0x0000001, true)),
                singlePlayerSpacer.getBorder()
        ));
        JLabel multiPlayerSpacer = new JLabel("MultiPlayer");
        multiPlayerSpacer.setFont(new Font("Arial", Font.BOLD, 14));
        multiPlayerSpacer.setForeground(new Color(0xBBBBBB));
        multiPlayerSpacer.setIcon(new ImageIcon("src\\images\\multiplayer.png"));
        multiPlayerSpacer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(3, 280, 0, 3, new Color(0x0000001, true)),
                multiPlayerSpacer.getBorder()
        ));

        add(singlePlayerSpacer);
        for (File saveFolder : singlePlayerFolders) {
            ImageIcon imageIcon = new ImageIcon("SinglePlayer\\" + saveFolder.getName() + "\\SaveDataThumbnail.png"); // load the image to a imageIcon
            Image image = imageIcon.getImage(); // transform it
            Image newimg = image.getScaledInstance(160, 100, java.awt.Image.SCALE_SMOOTH); // scale it the smooth way
            imageIcon = new ImageIcon(newimg);  // transform it back
            JButton button = new JButton(saveFolder.getName());
            button.addActionListener(e -> menu.loadSaveFromFolder("SinglePlayer\\" + saveFolder.getName() + "\\"));
            button.addActionListener(e -> menu.scrollPaneSaves.setVisible(false));
            button.addActionListener(e -> menu.scrollPaneData.setVisible(true));
            button.addActionListener(e -> menu.buttonLoad.setEnabled(true));
            button.addActionListener(e -> menu.buttonLoad.setText("Load Save Game\uD83D\uDD3D"));
            button.addActionListener(e -> menu.loadButtonState = false);
            ImageIcon finalImageIcon = imageIcon;
            button.addActionListener(e -> menu.labelSaveImage.setIcon(finalImageIcon));

            button.setAutoscrolls(true);
            button.setBackground(new Color(0x3C3F41));
            button.setOpaque(false);
            button.setBorderPainted(false);
            button.setFocusPainted(false);
            button.setFont(new Font("Arial", Font.BOLD, 14));
            button.setForeground(new Color(0xBBBBBB));
            button.setHorizontalAlignment(JButton.RIGHT);

            try (BufferedReader br = new BufferedReader(new FileReader("SinglePlayer\\" + saveFolder.getName() + "\\GameStateSaveData.json"))) {
                String line = br.readLine();
                String[] tempDetails = line.split(",");

                String saveTimeString = tempDetails[2];
                saveTimeString = saveTimeString.replace("\\\"SaveTime\\\":\\\"", "");
                saveTimeString = saveTimeString.replace("\\\"", "");

                LocalDateTime saveTime = LocalDateTime.parse(saveTimeString, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
                ZonedDateTime zonedSaveTime = saveTime.atZone(ZoneId.systemDefault());
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMMM yyyy - hh:mm:ssa");
                saveTimeString = zonedSaveTime.format(formatter);

                String day = tempDetails[5];
                day = day.replace("\\\"GameDays\\\":", "");
                String difficulty = tempDetails[3];
                difficulty = difficulty.replace("\\\"GameType\\\":\\\"", "");
                difficulty = difficulty.replace("\\\"", "");

                button.setText("Day:" + day + " - " + difficulty + ", " + saveTimeString + "  [" + saveFolder.getName() + "]");
            } catch (Exception e) {
                e.printStackTrace();
            }

            Image smallimg = image.getScaledInstance(80, 50, java.awt.Image.SCALE_SMOOTH); // scale it the smooth way
            imageIcon = new ImageIcon(smallimg);  // transform it back
            button.setIcon(imageIcon);
            button.setPreferredSize(new Dimension(400, 50));
            add(button,BorderLayout.NORTH);
        }

        add(multiPlayerSpacer);

        for (File saveFolder : multiPlayerFolders) {
            ImageIcon imageIcon = new ImageIcon("Multiplayer\\" + saveFolder.getName() + "\\SaveDataThumbnail.png"); // load the image to a imageIcon
            Image image = imageIcon.getImage(); // transform it
            Image newimg = image.getScaledInstance(160, 100, java.awt.Image.SCALE_SMOOTH); // scale it the smooth way
            imageIcon = new ImageIcon(newimg);  // transform it back
            JButton button = new JButton(saveFolder.getName());
            button.addActionListener(e -> menu.loadSaveFromFolder("Multiplayer\\" + saveFolder.getName() + "\\"));
            button.addActionListener(e -> menu.scrollPaneSaves.setVisible(false));
            button.addActionListener(e -> menu.scrollPaneData.setVisible(true));
            button.addActionListener(e -> menu.buttonLoad.setEnabled(true));
            button.addActionListener(e -> menu.buttonLoad.setText("Load Save Game\uD83D\uDD3D"));
            button.addActionListener(e -> menu.loadButtonState = false);
            ImageIcon finalImageIcon = imageIcon;
            button.addActionListener(e -> menu.labelSaveImage.setIcon(finalImageIcon));
            button.setAutoscrolls(true);
            button.setBackground(new Color(0x3C3F41));
            button.setOpaque(false);
            button.setBorderPainted(false);
            button.setFocusPainted(false);
            button.setFont(new Font("Arial", Font.BOLD, 14));
            button.setForeground(new Color(0xBBBBBB));
            button.setHorizontalAlignment(JButton.RIGHT);

            try (BufferedReader br = new BufferedReader(new FileReader("Multiplayer\\" + saveFolder.getName() + "\\GameStateSaveData.json"))) {
                String line = br.readLine();
                String[] tempDetails = line.split(",");

                String saveTimeString = tempDetails[2];
                saveTimeString = saveTimeString.replace("\\\"SaveTime\\\":\\\"", "");
                saveTimeString = saveTimeString.replace("\\\"", "");

                LocalDateTime saveTime = LocalDateTime.parse(saveTimeString, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
                ZonedDateTime zonedSaveTime = saveTime.atZone(ZoneId.systemDefault());
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMMM yyyy - hh:mm:ssa");
                saveTimeString = zonedSaveTime.format(formatter);

                String day = tempDetails[5];
                day = day.replace("\\\"GameDays\\\":", "");
                String difficulty = tempDetails[3];
                difficulty = difficulty.replace("\\\"GameType\\\":\\\"", "");
                difficulty = difficulty.replace("\\\"", "");

                button.setText("Day:" + day + " - " + difficulty + ", " + saveTimeString + "  [" + saveFolder.getName() + "]");
            } catch (Exception e) {
                e.printStackTrace();
            }

            Image smallimg = image.getScaledInstance(80, 50, java.awt.Image.SCALE_SMOOTH); // scale it the smooth way
            imageIcon = new ImageIcon(smallimg);  // transform it back
            button.setIcon(imageIcon);
            button.setPreferredSize(new Dimension(400, 50));

            add(button,BorderLayout.NORTH);
            add(Box.createVerticalStrut(1));
        }
    }

    //---[METHODS]---
    private List<File> getSinglePlayerFolders() {
        List<File> saveFolders = new ArrayList<>();

        try {
            File directory = new File("SinglePlayer");

            // TODO Extract a method to get file
            File[] directories = directory.listFiles(File::isDirectory);


            Arrays.sort(directories, new Comparator<File>() {
                public int compare(File f1, File f2) {
                    return Long.valueOf(f2.lastModified()).compareTo(f1.lastModified());
                }
            });

            for (File folder : directories) {
                if (folder.isDirectory() && folder.getName().matches("\\d+")) {
                    saveFolders.add(folder);
                }
            }
        }
        catch(NullPointerException nPE){
            JLabel error = new JLabel("No Singleplayer saves were found");
            error.setFont(new Font("Arial", Font.BOLD, 14));
            error.setForeground(new Color(0xC75450));
            error.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(3, 215, 0, 3, new Color(0x0000001, true)),
                    error.getBorder()
            ));
            add(error);
        }
        return saveFolders;
    }

    private List<File> getMultiPlayerFolders() {
        List<File> saveFolders = new ArrayList<>();

        try{
            File directory = new File("Multiplayer");
            // TODO Extract a method to get file
            File[] directories = directory.listFiles(File::isDirectory);

            Arrays.sort(directories, new Comparator<File>(){
                public int compare(File f1, File f2)
                {
                    return Long.valueOf(f2.lastModified()).compareTo(f1.lastModified());
                } });

            for (File folder : directories) {
                if (folder.isDirectory() && folder.getName().matches("\\d+")) {
                    saveFolders.add(folder);
                }
            }
        }
        catch(NullPointerException nPE){
            JLabel error = new JLabel("No Multiplayer saves were found");
            error.setFont(new Font("Arial", Font.BOLD, 14));
            error.setForeground(new Color(0xC75450));
            error.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(3, 220, 0, 3, new Color(0x0000001, true)),
                    error.getBorder()
            ));
            add(error);
        }

        return saveFolders;
    }

}


