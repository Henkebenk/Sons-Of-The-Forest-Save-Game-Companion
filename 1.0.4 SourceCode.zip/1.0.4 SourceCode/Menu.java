import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


public class Menu{
    //---[DECLARATIONS]---
    private JPanel panel1;
    public JButton buttonLoad;
    private JLabel labelKelvinCoordinatesTxt;
    private JLabel labelVirginiaCoordinatesTxt;
    private JLabel labelKelvinIsDeadTxt;
    private JLabel labelVirginiaIsDeadTxt;
    private JPanel panelVirginiaAlive;
    private JPanel panelKelvinAlive;
    private JLabel labelVirginiaStatus;
    private JLabel labelKelvinStatus;
    private JPanel panelKelvinPosition;
    private JPanel panelVirginiaPosition;
    private JButton buttonKelvinRevive;
    private JButton buttonKelvinTPVirginia;
    private JButton buttonVirginiaRevive;
    private JButton buttonVirginiaTPKelvin;
    private JButton buttonRegrowAllTrees;
    private JButton loadStateFromSaveButton;
    private JPanel panelTreesCut;
    private JButton buttonVirginiaTPPlayer;
    private JButton buttonKelvinTPPlayer;
    private JButton buttonPlayer;
    private JPanel panelLoadSaves;
    private JButton buttonCompanions;
    private JButton buttonEnviroment;
    private JButton buttonKelvinShowInventory;
    private JButton buttonVirginiaShowInventory;
    private JPanel panelKelvinInventory;
    private JPanel panelKelvinInventoryOutfit;
    private JLabel labelKelvinOutfitTxt;
    private JLabel labelKelvinOutfit;
    private JPanel panelVirginiaInventory;
    private JPanel panelVirginiaInventoryOutfit;
    private JLabel labelVirginiaOutfitTxt;
    private JLabel labelVirginiaOutfit;
    private JLabel labelUtilTxt;
    private JLabel checkHandgun;
    private JLabel checkShotgun;
    private JLabel checkGps;
    private JLabel labelVirginiaHandgun;
    private JLabel labelVirginiaShotgun;
    private JLabel labelVirginiaGPS;
    private JLabel labelKelvinCoordinates;
    private JLabel labelVirginiaCoordinates;
    private JPanel panelVirginiaInventoryUtil;
    private JPanel panelVirginiaInventoryUtilSub;
    private JProgressBar progressBarVirginiaAffection;
    private JPanel panelVirginiaProgressBarAffinity;
    private JPanel panelVirginiaStats;
    private JPanel panelVirginiaProgressBarHealth;
    private JPanel panelVirginiaProgressBarHydration;
    private JPanel panelVirginiaProgressBarEnergy;
    private JPanel panelKelvinStats;
    private JPanel panelKelvinProgressBarAffinity;
    private JPanel panelKelvinProgressBarHealth;
    private JPanel panelKelvinProgressBarHydration;
    private JPanel panelKelvinProgressBarEnergy;
    private JLabel labelPlayerCoordinates;
    private JPanel panelPlayerAmmo;
    private JTextField textPlayerBuckshot;
    private JTextField textPlayerSlug;
    private JTextField textPlayerPistol;
    private JTextField textPlayerCarbon;
    private JTextField textPlayerPrinted;
    private JTextField textPlayerStone;
    private JProgressBar progressBarKelvinHealth;
    private JProgressBar progressBarKelvinEnergy;
    private JProgressBar progressBarKelvinHydration;
    private JProgressBar progressBarKelvinAffection;
    private JProgressBar progressBarVirginiaHealth;
    private JProgressBar progressBarVirginiaEnergy;
    private JProgressBar progressBarVirginiaHydration;
    private JProgressBar progressBarPlayerHealth;
    private JProgressBar progressBarPlayerEnergy;
    private JProgressBar progressBarPlayerRest;
    private JProgressBar progressBarPlayerFullness;
    private JProgressBar progressBarPlayerHydration;
    private JTextField textVirginiaHealth;
    private JTextField textVirginiaEnergy;
    private JTextField textVirginiaHydration;
    private JTextField textVirginiaAffection;
    private JTextField textKelvinHealth;
    private JTextField textKelvinEnergy;
    private JTextField textKelvinHydration;
    private JTextField textKelvinAffection;
    private JTextField textPlayerHealth;
    private JTextField textPlayerEnergy;
    private JTextField textPlayerRest;
    private JTextField textPlayerFullness;
    private JTextField textPlayerHydration;
    public JLabel labelSaveImage;
    private JButton buttonPeaceful;
    private JButton buttonNormal;
    private JButton buttonHard;
    private JLabel labelNumberOfTrees;
    private JButton buttonRegrowAllStumps;
    private JLabel labelSaveTime;
    private JLabel labelSaveDayDifficulty;
    private JLabel labelSaveSpawn;
    private JLabel labelStoryComplete;
    public JScrollPane scrollPaneSaves;
    public JPanel panelAllSaves;
    public JScrollPane scrollPaneData;
    private JPanel panelSave;
    private JPanel pP;
    private JPanel pC;
    private JPanel pE;
    private JPanel pSub;
    private JPanel panelSaveSub;
    private JPanel pPSub;
    private JLabel imagePlayer;
    private JPanel panelHealth;
    private JPanel panelEnergy;
    private JPanel panelRest;
    private JPanel panelFullness;
    private JPanel panelHydration;
    private JPanel panelLoadSavesNew;
    private JPanel panelLoadSavesSub;
    private JPanel panelPlayerThrowables;
    private JTextField textPlayerGrenade;
    private JTextField textPlayerFlare;
    private JTextField textPlayerTimeBomb;
    private JTextField textPlayerMolotov;
    private JButton buttonSaveChanges;
    public JLabel labelError;
    public JLabel labelTestibest;
    private boolean virginiaInventoryVisible = false;
    private boolean kelvinInventoryVisible = false;
    private static Mod m;
    private Color myGreen = new Color(0x499C54);
    private Color myRed = new Color(0xC75450);
    private String filePath;
    public boolean loadButtonState = false;
    public boolean changedSaveData = false, changedGameStateSaveData = false, changedWorldObjectLocatorManager = false, changedPlayerStateSaveData = false, changedPlayerInventorySaveData = false;



    //---[CONSTRUCTORS]---
    public Menu() {
        buttonKelvinShowInventory.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (kelvinInventoryVisible){
                    panelKelvinInventory.setVisible(false);
                    kelvinInventoryVisible = false;
                    buttonKelvinShowInventory.setText("Show Inventory");
                }
                else{
                    panelKelvinInventory.setVisible(true);
                    kelvinInventoryVisible = true;
                    buttonKelvinShowInventory.setText("Hide Inventory");
                }
            }
        });
        buttonVirginiaShowInventory.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (virginiaInventoryVisible){
                    panelVirginiaInventory.setVisible(false);
                    virginiaInventoryVisible = false;
                    buttonVirginiaShowInventory.setText("Show Inventory");
                }
                else{
                    panelVirginiaInventory.setVisible(true);
                    virginiaInventoryVisible = true;
                    buttonVirginiaShowInventory.setText("Hide Inventory");
                }
            }
        });
        buttonLoad.addActionListener(new ActionListener() {//---LOAD BUTTON
            @Override
            public void actionPerformed(ActionEvent e) {
                if(loadButtonState){ //Panel is up
                    scrollPaneSaves.setVisible(false);
                    buttonLoad.setText("Load Save Game\uD83D\uDD3D");
                    loadButtonState = false;
                }
                else{ //Panel is down
                    scrollPaneSaves.setVisible(true);
                    buttonLoad.setText("Load Save Game\uD83D\uDD3C");
                    loadButtonState = true;
                }

            }
        });
        textPlayerHealth.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{progressBarPlayerHealth.setValue(Integer.parseInt(textPlayerHealth.getText())); m.player.health = textPlayerHealth.getText();m.setPlayerStats();changedPlayerStateSaveData = true; buttonSaveChanges.setVisible(true);}
                catch(NumberFormatException nfe){System.out.println("Wrong number format");}
            }
        });
        textPlayerEnergy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{progressBarPlayerEnergy.setValue(Integer.parseInt(textPlayerEnergy.getText())); m.player.energy = textPlayerEnergy.getText();m.setPlayerStats();changedPlayerStateSaveData = true; buttonSaveChanges.setVisible(true);}
                catch(NumberFormatException nfe){System.out.println("Wrong number format");}
            }
        });
        textPlayerRest.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{progressBarPlayerRest.setValue(Integer.parseInt(textPlayerRest.getText())); m.player.rest = textPlayerRest.getText();m.setPlayerStats();changedPlayerStateSaveData = true; buttonSaveChanges.setVisible(true);}
                catch(NumberFormatException nfe){System.out.println("Wrong number format");}
            }
        });
        textPlayerFullness.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{progressBarPlayerFullness.setValue(Integer.parseInt(textPlayerFullness.getText())); m.player.fullness = textPlayerFullness.getText();m.setPlayerStats();changedPlayerStateSaveData = true; buttonSaveChanges.setVisible(true);}
                catch(NumberFormatException nfe){System.out.println("Wrong number format");}
            }
        });
        textPlayerHydration.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{progressBarPlayerHydration.setValue(Integer.parseInt(textPlayerHydration.getText())); m.player.hydration = textPlayerHydration.getText();m.setPlayerStats();changedPlayerStateSaveData = true; buttonSaveChanges.setVisible(true);}
                catch(NumberFormatException nfe){System.out.println("Wrong number format");}
            }
        });
        textPlayerBuckshot.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    Integer.parseInt(textPlayerBuckshot.getText());
                    m.player.ammoBuck = textPlayerBuckshot.getText();m.setPlayerAmmo();changedPlayerInventorySaveData = true; buttonSaveChanges.setVisible(true);
                }
                catch(NumberFormatException nfe){
                    System.out.println("Wrong number format");
                }
            }
        });
        textPlayerSlug.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    Integer.parseInt(textPlayerSlug.getText());
                    m.player.ammoSlug = textPlayerSlug.getText();m.setPlayerAmmo();changedPlayerInventorySaveData = true; buttonSaveChanges.setVisible(true);
                }
                catch(NumberFormatException nfe){
                    System.out.println("Wrong number format");
                }
            }
        });
        textPlayerPistol.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    Integer.parseInt(textPlayerPistol.getText());
                    m.player.ammoPistol = textPlayerPistol.getText();m.setPlayerAmmo();changedPlayerInventorySaveData = true; buttonSaveChanges.setVisible(true);
                }
                catch(NumberFormatException nfe){
                    System.out.println("Wrong number format");
                }
            }
        });
        textPlayerCarbon.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    Integer.parseInt(textPlayerCarbon.getText());
                    m.player.ammoArrowCarbon = textPlayerCarbon.getText();m.setPlayerAmmo();changedPlayerInventorySaveData = true; buttonSaveChanges.setVisible(true);
                }
                catch(NumberFormatException nfe){
                    System.out.println("Wrong number format");
                }
            }
        });
        textPlayerPrinted.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    Integer.parseInt(textPlayerPrinted.getText());
                    m.player.ammoArrowPrinted = textPlayerPrinted.getText();m.setPlayerAmmo();changedPlayerInventorySaveData = true; buttonSaveChanges.setVisible(true);
                }
                catch(NumberFormatException nfe){
                    System.out.println("Wrong number format");
                }
            }
        });
        textPlayerStone.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    Integer.parseInt(textPlayerStone.getText());
                    m.player.ammoArrowStone = textPlayerStone.getText();m.setPlayerAmmo();changedPlayerInventorySaveData = true; buttonSaveChanges.setVisible(true);
                }
                catch(NumberFormatException nfe){
                    System.out.println("Wrong number format");
                }
            }
        });
        buttonKelvinTPPlayer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                m.kelvin.coordinates = m.player.coordinates;
                labelKelvinCoordinates.setText(m.kelvin.writeCoordinates());m.setCompanionCoordinates();changedSaveData = true; buttonSaveChanges.setVisible(true);;
            }
        });
        buttonKelvinTPVirginia.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                m.kelvin.coordinates = m.virginia.coordinates;
                labelKelvinCoordinates.setText(m.kelvin.writeCoordinates());m.setCompanionCoordinates();changedSaveData = true; buttonSaveChanges.setVisible(true);;
            }
        });
        buttonVirginiaTPPlayer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                m.virginia.coordinates = m.player.coordinates;
                labelVirginiaCoordinates.setText(m.virginia.writeCoordinates());m.setCompanionCoordinates();changedSaveData = true; buttonSaveChanges.setVisible(true);;
            }
        });
        buttonVirginiaTPKelvin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                m.virginia.coordinates = m.kelvin.coordinates;
                labelVirginiaCoordinates.setText(m.virginia.writeCoordinates());m.setCompanionCoordinates();changedSaveData = true; buttonSaveChanges.setVisible(true);;
            }
        });
        textKelvinHealth.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{progressBarKelvinHealth.setValue(Integer.parseInt(textKelvinHealth.getText())); m.kelvin.health = textKelvinHealth.getText();m.setKelvinStats();changedSaveData = true; buttonSaveChanges.setVisible(true);}
                catch(NumberFormatException nfe){System.out.println("Wrong number format");}
            }
        });
        textKelvinEnergy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{progressBarKelvinEnergy.setValue(Integer.parseInt(textKelvinEnergy.getText())); m.kelvin.energy = textKelvinEnergy.getText();m.setKelvinStats();changedSaveData = true; buttonSaveChanges.setVisible(true);}
                catch(NumberFormatException nfe){System.out.println("Wrong number format");}
            }
        });
        textKelvinHydration.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{progressBarKelvinHydration.setValue(Integer.parseInt(textKelvinHydration.getText())); m.kelvin.hydration = textKelvinHydration.getText();m.setKelvinStats();changedSaveData = true; buttonSaveChanges.setVisible(true);}
                catch(NumberFormatException nfe){System.out.println("Wrong number format");}
            }
        });
        textKelvinAffection.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{progressBarKelvinAffection.setValue(Integer.parseInt(textKelvinAffection.getText())); m.kelvin.affection = textKelvinAffection.getText();m.setKelvinStats();changedSaveData = true; buttonSaveChanges.setVisible(true);}
                catch(NumberFormatException nfe){System.out.println("Wrong number format");}
            }
        });
        textVirginiaHealth.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{progressBarVirginiaHealth.setValue(Integer.parseInt(textVirginiaHealth.getText())); m.virginia.health = textVirginiaHealth.getText();m.setVirginiaStats();changedSaveData = true; buttonSaveChanges.setVisible(true);}
                catch(NumberFormatException nfe){System.out.println("Wrong number format");}
            }
        });
        textVirginiaEnergy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{progressBarVirginiaEnergy.setValue(Integer.parseInt(textVirginiaEnergy.getText())); m.virginia.energy = textVirginiaEnergy.getText();m.setVirginiaStats();changedSaveData = true; buttonSaveChanges.setVisible(true);}
                catch(NumberFormatException nfe){System.out.println("Wrong number format");}
            }
        });
        textVirginiaHydration.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{progressBarVirginiaHydration.setValue(Integer.parseInt(textVirginiaHydration.getText())); m.virginia.hydration = textVirginiaHydration.getText();m.setVirginiaStats();changedSaveData = true; buttonSaveChanges.setVisible(true);}
                catch(NumberFormatException nfe){System.out.println("Wrong number format");}
            }
        });
        textVirginiaAffection.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{progressBarVirginiaAffection.setValue(Integer.parseInt(textVirginiaAffection.getText())); m.virginia.affection = textVirginiaAffection.getText();m.setVirginiaStats();changedSaveData = true; buttonSaveChanges.setVisible(true);}
                catch(NumberFormatException nfe){System.out.println("Wrong number format");}
            }
        });
        buttonRegrowAllTrees.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                m.regrowAllTrees();
                labelNumberOfTrees.setText(m.numberOfTrees + "x");
            }
        });
        buttonRegrowAllStumps.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                m.regrowStumps();
                labelNumberOfTrees.setText(m.numberOfTrees + "x");
            }
        });
        buttonPeaceful.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                m.saveDifficulty = "Peaceful"; m.setSaveDifficulty(); changedGameStateSaveData = true; buttonSaveChanges.setVisible(true);
                labelSaveDayDifficulty.setText(m.saveDaysDifficulty);
            }
        });
        buttonNormal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                m.saveDifficulty = "Normal"; m.setSaveDifficulty(); changedGameStateSaveData = true; buttonSaveChanges.setVisible(true);
                labelSaveDayDifficulty.setText(m.saveDaysDifficulty);
            }
        });
        buttonHard.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                m.saveDifficulty = "Hard"; m.setSaveDifficulty(); changedGameStateSaveData = true; buttonSaveChanges.setVisible(true);
                labelSaveDayDifficulty.setText(m.saveDaysDifficulty);
            }
        });
        buttonKelvinRevive.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                progressBarKelvinHealth.setValue(100); textKelvinHealth.setText("100");m.kelvin.health = "100";m.setKelvinStats();
                m.reviveCompanion(m.kelvin);changedGameStateSaveData = true; changedSaveData = true; buttonSaveChanges.setVisible(true);
                labelKelvinStatus.setText("Alive"); labelKelvinStatus.setForeground(myGreen);
                buttonKelvinRevive.setVisible(false);
            }
        });
        buttonVirginiaRevive.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                progressBarVirginiaHealth.setValue(100); textVirginiaHealth.setText("100");m.virginia.health = "100";m.setVirginiaStats();
                m.reviveCompanion(m.virginia);changedGameStateSaveData = true; changedSaveData = true; buttonSaveChanges.setVisible(true);
                labelVirginiaStatus.setText("Alive"); labelVirginiaStatus.setForeground(myGreen);
                buttonVirginiaRevive.setVisible(false);
            }
        });
        textPlayerGrenade.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    Integer.parseInt(textPlayerGrenade.getText());
                    m.player.throwablesFrag = textPlayerGrenade.getText();m.setPlayerThrowables();changedPlayerInventorySaveData = true; buttonSaveChanges.setVisible(true);
                }
                catch(NumberFormatException nfe){
                    System.out.println("Wrong number format");
                }
            }
        });
        textPlayerFlare.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    Integer.parseInt(textPlayerFlare.getText());
                    m.player.throwablesFlare = textPlayerFlare.getText();m.setPlayerThrowables();changedPlayerInventorySaveData = true; buttonSaveChanges.setVisible(true);
                }
                catch(NumberFormatException nfe){
                    System.out.println("Wrong number format");
                }
            }
        });
        textPlayerTimeBomb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    Integer.parseInt(textPlayerTimeBomb.getText());
                    m.player.throwablesTimeBomb = textPlayerTimeBomb.getText();m.setPlayerThrowables();changedPlayerInventorySaveData = true; buttonSaveChanges.setVisible(true);
                }
                catch(NumberFormatException nfe){
                    System.out.println("Wrong number format");
                }
            }
        });
        textPlayerMolotov.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    Integer.parseInt(textPlayerMolotov.getText());
                    m.player.throwablesMolotov = textPlayerMolotov.getText();m.setPlayerThrowables();changedPlayerInventorySaveData = true; buttonSaveChanges.setVisible(true);
                }
                catch(NumberFormatException nfe){
                    System.out.println("Wrong number format");
                }
            }
        });
        buttonSaveChanges.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Backup();
                if(changedSaveData){
                    m.saveSaveData();
                }
                if(changedGameStateSaveData){
                    m.saveGameStateSaveData();
                }
                if(changedWorldObjectLocatorManager){
                    m.saveWorldObjectLocatorManagerSaveData();
                }
                if(changedPlayerStateSaveData){
                    m.savePlayerStateSaveData();
                }
                if(changedPlayerInventorySaveData){
                    m.savePlayerInventorySaveData();
                }
                changedSaveData = false; changedGameStateSaveData = false; changedWorldObjectLocatorManager = false; changedPlayerStateSaveData = false; changedPlayerInventorySaveData = false;
                buttonSaveChanges.setVisible(false);
            }
        });
    }

    //---[METHODS]---
    public void Backup(){
        Path saveGameFolder = Paths.get(m.getFilePath().substring(0, m.getFilePath().length()-1));
        System.out.println("Path to save folder: " + saveGameFolder);
        Path backupFolder = Paths.get(saveGameFolder.toString() + "_Backup");
        System.out.println("Path to backup folder: " + backupFolder);

        try {
            // Check if backup folder already exists
            if (Files.exists(backupFolder)) {
                System.out.println("Backup folder already exists. Skipping backup.");
            } else {
                // Create backup folder
                Files.createDirectory(backupFolder);

                // Copy all files and subdirectories from save game folder to backup folder
                Files.walk(saveGameFolder).forEach(source -> {
                    try {
                        Path destination = backupFolder.resolve(saveGameFolder.relativize(source));
                        Files.copy(source, destination);
                    } catch (IOException e) {
                        System.out.println("Failed to copy file " + source);
                    }
                });
            }
        } catch (IOException e) {
            System.out.println("Failed to create backup folder.");
        }
    }
    public Mod getMod(){
        return m;
    }

    public String getFilePath(){
        return filePath;
    }

    public void loadGameTypeSaves(){
        panelLoadSaves = new SaveFolderPanel(this);
    }

    public void loadSaveFromFolder(String folderName){
        m = new Mod();
        m.load(folderName);
        labelSaveTime.setText(m.saveTimeString);
        labelSaveDayDifficulty.setText(m.saveDaysDifficulty);
        labelSaveSpawn.setText(m.saveSpawn);
        labelStoryComplete.setText(m.storyComplete);
        labelKelvinCoordinates.setText(m.kelvin.writeCoordinates());
        labelVirginiaCoordinates.setText(m.virginia.writeCoordinates());
        labelPlayerCoordinates.setText(m.player.writeCoordinates());
        progressBarKelvinHealth.setValue((int) Double.parseDouble(m.kelvin.health));textKelvinHealth.setText(m.kelvin.healthInt);
        progressBarKelvinEnergy.setValue((int) Double.parseDouble(m.kelvin.energy));textKelvinEnergy.setText(m.kelvin.energyInt);
        progressBarKelvinHydration.setValue((int) Double.parseDouble(m.kelvin.hydration));textKelvinHydration.setText(m.kelvin.hydrationInt);
        progressBarKelvinAffection.setValue((int) Double.parseDouble(m.kelvin.affection));textKelvinAffection.setText(m.kelvin.affectionInt);
        progressBarVirginiaHealth.setValue((int) Double.parseDouble(m.virginia.health));textVirginiaHealth.setText(m.virginia.healthInt);
        progressBarVirginiaEnergy.setValue((int) Double.parseDouble(m.virginia.energy));textVirginiaEnergy.setText(m.virginia.energyInt);
        progressBarVirginiaHydration.setValue((int) Double.parseDouble(m.virginia.hydration));textVirginiaHydration.setText(m.virginia.hydrationInt);
        progressBarVirginiaAffection.setValue((int) Double.parseDouble(m.virginia.affection));textVirginiaAffection.setText(m.virginia.affectionInt);
        progressBarPlayerHealth.setMaximum(Integer.parseInt(m.player.maxHealthInt));progressBarPlayerHealth.setValue((int) Double.parseDouble(m.player.health));
        progressBarPlayerEnergy.setValue((int) Double.parseDouble(m.player.energy));
        progressBarPlayerFullness.setValue((int) Double.parseDouble(m.player.fullness));
        progressBarPlayerHydration.setValue((int) Double.parseDouble(m.player.hydration));
        labelKelvinStatus.setText(m.kelvin.aliveStatus);
        labelVirginiaStatus.setText(m.virginia.aliveStatus);
        labelKelvinOutfit.setText(m.kelvin.outfitName);
        labelVirginiaOutfit.setText(m.virginia.outfitName);
        textPlayerBuckshot.setText(m.player.ammoBuck);
        textPlayerSlug.setText(m.player.ammoSlug);
        textPlayerPistol.setText(m.player.ammoPistol);
        textPlayerCarbon.setText(m.player.ammoArrowCarbon);
        textPlayerPrinted.setText(m.player.ammoArrowPrinted);
        textPlayerStone.setText(m.player.ammoArrowStone);
        textPlayerGrenade.setText(m.player.throwablesFrag);
        textPlayerFlare.setText(m.player.throwablesFlare);
        textPlayerTimeBomb.setText(m.player.throwablesTimeBomb);
        textPlayerMolotov.setText(m.player.throwablesMolotov);

        textPlayerHealth.setText(m.player.healthInt);
        textPlayerEnergy.setText(m.player.energyInt);
        textPlayerFullness.setText(m.player.fullnessInt);
        textPlayerHydration.setText(m.player.hydrationInt);

        if(m.virginia.virginiaTracker){labelVirginiaGPS.setForeground(myGreen);checkGps.setText("🗸");checkGps.setForeground(myGreen);}
        else{labelVirginiaGPS.setForeground(myRed);checkGps.setText("X");checkGps.setForeground(myRed);}
        if(m.virginia.virginiaPistol){labelVirginiaHandgun.setForeground(myGreen);checkHandgun.setText("🗸");checkHandgun.setForeground(myGreen);}
        else{labelVirginiaHandgun.setForeground(myRed);checkHandgun.setText("X");checkHandgun.setForeground(myRed);}
        if(m.virginia.virginiaShotgun){labelVirginiaShotgun.setForeground(myGreen);checkShotgun.setText("🗸");checkShotgun.setForeground(myGreen);}
        else{labelVirginiaShotgun.setForeground(myRed);checkShotgun.setText("X");checkShotgun.setForeground(myRed);}
        labelNumberOfTrees.setText(m.numberOfTrees + "x");

        if(m.kelvinDead){
            labelKelvinStatus.setForeground(myRed);
            buttonKelvinRevive.setEnabled(true);buttonKelvinRevive.setVisible(true);
        }
        else{
            labelKelvinStatus.setForeground(myGreen);
            buttonKelvinRevive.setEnabled(false);buttonKelvinRevive.setVisible(false);
        }
        if(m.virginiaDead){
            labelVirginiaStatus.setForeground(myRed);
            buttonVirginiaRevive.setEnabled(true);buttonVirginiaRevive.setVisible(true);
        }
        else{
            labelVirginiaStatus.setForeground(myGreen);
            buttonVirginiaRevive.setEnabled(false);buttonVirginiaRevive.setVisible(false);
        }

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Sons Of The Forest | Save Game Companion");
        frame.setContentPane(new Menu().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        Menu main = new Menu(); // TODO: Maybe remove this
        ImageIcon img = new ImageIcon("src\\images\\logo.png");
        frame.setIconImage(img.getImage());
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
        labelError = new JLabel();
        labelError.setVisible(false);
        scrollPaneSaves = new JScrollPane();
        scrollPaneSaves.getVerticalScrollBar().setUnitIncrement(16);
        scrollPaneData = new JScrollPane();
        scrollPaneData.getVerticalScrollBar().setUnitIncrement(16);
        panelAllSaves = new JPanel();
        panelLoadSavesSub = new SaveFolderPanel(this);
        textPlayerBuckshot = new JTextField(); textPlayerSlug = new JTextField(); textPlayerPistol = new JTextField(); textPlayerCarbon = new JTextField(); textPlayerPrinted = new JTextField(); textPlayerStone = new JTextField();
        textPlayerGrenade = new JTextField(); textPlayerFlare = new JTextField(); textPlayerTimeBomb = new JTextField(); textPlayerMolotov = new JTextField();
        textVirginiaHealth = new JTextField(); textVirginiaEnergy = new JTextField(); textVirginiaHydration = new JTextField(); textVirginiaAffection = new JTextField();
        textKelvinHealth = new JTextField(); textKelvinEnergy = new JTextField(); textKelvinHydration = new JTextField(); textKelvinAffection = new JTextField();
        textPlayerHealth = new JTextField(); textPlayerEnergy = new JTextField(); textPlayerRest = new JTextField(); textPlayerFullness = new JTextField(); textPlayerHydration = new JTextField();
        textPlayerBuckshot.setBorder(BorderFactory.createEmptyBorder());
        textPlayerSlug.setBorder(BorderFactory.createEmptyBorder());
        textPlayerPistol.setBorder(BorderFactory.createEmptyBorder());
        textPlayerCarbon.setBorder(BorderFactory.createEmptyBorder());
        textPlayerPrinted.setBorder(BorderFactory.createEmptyBorder());
        textPlayerStone.setBorder(BorderFactory.createEmptyBorder());
        textPlayerGrenade.setBorder(BorderFactory.createEmptyBorder());
        textPlayerFlare.setBorder(BorderFactory.createEmptyBorder());
        textPlayerTimeBomb.setBorder(BorderFactory.createEmptyBorder());
        textPlayerMolotov.setBorder(BorderFactory.createEmptyBorder());
        textVirginiaHealth.setBorder(BorderFactory.createEmptyBorder());
        textVirginiaEnergy.setBorder(BorderFactory.createEmptyBorder());
        textVirginiaHydration.setBorder(BorderFactory.createEmptyBorder());
        textVirginiaAffection.setBorder(BorderFactory.createEmptyBorder());
        textKelvinHealth.setBorder(BorderFactory.createEmptyBorder());
        textKelvinEnergy.setBorder(BorderFactory.createEmptyBorder());
        textKelvinHydration.setBorder(BorderFactory.createEmptyBorder());
        textKelvinAffection.setBorder(BorderFactory.createEmptyBorder());
        textPlayerHealth.setBorder(BorderFactory.createEmptyBorder());
        textPlayerEnergy.setBorder(BorderFactory.createEmptyBorder());
        textPlayerRest.setBorder(BorderFactory.createEmptyBorder());
        textPlayerFullness.setBorder(BorderFactory.createEmptyBorder());
        textPlayerHydration.setBorder(BorderFactory.createEmptyBorder());
        labelSaveImage = new JLabel();

    }
}
